#include <stdio.h>

main()
{

    int fact = 1, n;

    for (int i = 1; i <= n; i++)

    {
        fact = fact * i;
    }

    printf("Factorial Value of N is", fact);
}